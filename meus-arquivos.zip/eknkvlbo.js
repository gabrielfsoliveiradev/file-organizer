Arquivo de teste eknkvlbo.js
